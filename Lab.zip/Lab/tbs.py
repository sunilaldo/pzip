import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 20, 50)
y = np.sin(x)

plt.plot(x, y, label='sin(x)', color='blue')
plt.title("Matplotlib Line Plot")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend()
plt.grid(True)
plt.show()

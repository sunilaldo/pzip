import matplotlib.pyplot as plt
def plot_averages(averages):
    """Plot a bar chart of average scores."""
    subjects = list(averages.keys())
    scores = list(averages.values())
    plt.bar(subjects, scores, color=['red', 'black', 'yellow'])
    plt.xlabel('Subjects')
    plt.ylabel('Average Score')
    plt.title('Average Scores by Subject')
    plt.show()

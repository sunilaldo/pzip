def power(x, y):
    if y == 0:
        return 1
    if y % 2 == 0:
        return power(x, y // 2) * power(x, y // 2)
    return x * power(x, y // 2) * power(x, y // 2)

def order(x):
    n = 0
    while x != 0:
        n += 1
        x //= 10
    return n

def isArmstrong(x):
    n = order(x)  # Find the number of digits
    temp = x
    sum1 = 0
    while temp != 0:
        r = temp % 10
        sum1 += power(r, n)
        temp //= 10
    return sum1 == x

# Testing the function
x = 23
print(isArmstrong(x))  # Output: False
x = 1
print(isArmstrong(x))  # Output: True

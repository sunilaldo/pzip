inventory = {}

def display_inventory():
    if inventory:
        for item, quantity in inventory.items():
            print(f"{item}: {quantity}")
    else:
        print("Inventory is empty.")

def add_or_update_item():
    item = input("Enter item name: ")
    try:
        quantity = int(input(f"Enter quantity for {item}: "))
        inventory[item] = inventory.get(item, 0) + quantity
        print(f"{item} updated with {inventory[item]} in stock.")
    except ValueError:
        print("Invalid input. Quantity must be a number.")

def remove_item():
    item = input("Enter item to remove: ")
    if item in inventory:
        del inventory[item]
        print(f"{item} removed.")
    else:
        print(f"{item} not found.")

def main():
    while True:
        print("\n1. Display Inventory\n2. Add/Update Item\n3. Remove Item\n4. Exit")
        choice = input("Choose an option: ")
        if choice == "1":
            display_inventory()
        elif choice == "2":
            add_or_update_item()
        elif choice == "3":
            remove_item()
        elif choice == "4":
            print("Exiting the program. Goodbye!")
            break
        else:
            print("Invalid choice. Please choose a valid option.")

if __name__ == "__main__":
    main()

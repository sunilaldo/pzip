import altair as alt
import pandas as pd

df = pd.DataFrame({'x': range(10), 'y': [i**2 for i in range(10)]})

chart = alt.Chart(df).mark_circle(size=100).encode(
    x='x',
    y='y',
    tooltip=['x', 'y']
).properties(title="Altair Scatter Plot")
chart.show()

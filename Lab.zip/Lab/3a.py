# Create an empty list
a = []

# Input the number of elements in the list
n = int(input("Enter the number of elements: "))

# Populate the list with user inputs
for i in range(1, n + 1):
    b = int(input("Enter element: "))
    a.append(b)

# Input the number to search for
x = int(input("Enter number to search: "))

# Initialize a flag to check if the number is found
found = False

# Search for the number in the list
for i in range(len(a)):
    if a[i] == x:
        found = True
        print("%d found at %dth position" % (x, i + 1))  # Display 1-based position
        break

# If the number is not found, print a message
if not found:
    print("%d is not in the list" % x)

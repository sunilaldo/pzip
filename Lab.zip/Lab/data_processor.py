import numpy as np
def calculate_averages(data):
    """Calculate average scores for each subject."""
    averages = {"French": np.mean(data['French']),"English": np.mean(data['English']),"Tamil": np.mean(data['Tamil'])}
    return averages
def get_student_scores(data, student_name):
    """Get scores for a specific student."""
    student = data[data['Name'] == student_name]
    if not student.empty:
        return student[['French', 'English', 'Tamil']].values[0]
    else:
        print("Student not found.")
        return None

def rev_number(n):
    s = 0  # Keeps track of the number of iterations (optional, unused in output)
    while True:
        k = str(n)  # Convert the number to a string
        if k == k[::-1]:  # Check if it's a palindrome
            break  # Exit the loop if palindrome is found
        else:
            m = int(k[::-1])  # Reverse the digits
            n += m  # Add the reversed number to the original
            s += 1  # Increment the iteration count
    return n

# Input from the user
rev = int(input("Enter a number: "))  # Prompt for a number
print("Palindromic number:", rev_number(rev))  # Print the resulting palindrome

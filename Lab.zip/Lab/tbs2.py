import plotly.express as px
import pandas as pd

# Sample data
df = pd.DataFrame({'x': range(20), 'y': [i**2 for i in range(20)]})

fig = px.scatter(df, x='x', y='y', title="Plotly Interactive Scatter Plot")
fig.show()

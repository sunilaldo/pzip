# Selection Sort in Python
# Time complexity: O(n^2)
# Sorting by finding the minimum index

def selectionSort(array, size):
    for ind in range(size):
        min_index = ind
        for j in range(ind + 1, size):
            # Select the minimum element in every iteration
            if array[j] < array[min_index]:
                min_index = j
        # Swap the elements to sort the array
        array[ind], array[min_index] = array[min_index], array[ind]

# Input array
arr = [-2, -54, -1, 0, 21, -11, 88, 97, 22, -47]
size = len(arr)

# Call the sorting function
selectionSort(arr, size)

# Print the sorted array
print("The array after sorting in Ascending Order by selection sort is:")
print(arr)

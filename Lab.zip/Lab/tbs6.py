from bokeh.plotting import figure, show
from bokeh.io import output_notebook
import numpy as np

x = np.linspace(0, 10, 100)
y = np.sin(x)

output_notebook()
p = figure(title="Bokeh Line Plot", x_axis_label='X', y_axis_label='Y')
p.line(x, y, legend_label="sin(x)", line_width=2, color="blue")

show(p)

from scipy.stats import ttest_ind
def ttest_between_subjects(data, subject1, subject2):
    """Perform t-test between two subjects to check if their scores are significantly different."""
    scores1 = data[subject1]
    scores2 = data[subject2]
    t_stat, p_value = ttest_ind(scores1, scores2)
    return t_stat, p_value
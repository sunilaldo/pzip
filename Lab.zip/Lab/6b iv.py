# Creating a tuple
Tuple_data = (0, 1, 2, 93, 52, 93, 31, 93, 12)

# Getting the index of the element `3`
try:
    res = Tuple_data.index(93)  # `index()` is a method, not accessed with brackets `[]`
    print('First occurrence of 93 is at index:', res)
except ValueError:
    print('The element 93 is not found in the tuple.')

# Getting the index of `3` after the 4th index
try:
    res = Tuple_data.index(93, 4)  # Start searching from index 4
    print('First occurrence of 93 after the 4th index is at index:', res)
except ValueError:
    print('The element 93 is not found after the 4th index in the tuple.')

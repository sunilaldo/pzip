import altair as alt
import pandas as pd
import numpy as np

# Create a sample dataset
data = pd.DataFrame({
    'x': np.repeat(range(10), 10),
    'y': list(range(10)) * 10,
    'z': np.random.rand(100)
})

chart = alt.Chart(data).mark_rect().encode(
    x='x:O',
    y='y:O',
    color='z:Q'
).properties(title="Altair Heatmap")
chart.show()

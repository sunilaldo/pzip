# Binary Search Function
def Binary_search(arr, start_index, last_index, element):
    while start_index <= last_index:
        mid = (start_index + last_index) // 2  # Calculate middle index
        
        if element > arr[mid]:  # If element is in the right half
            start_index = mid + 1
        elif element < arr[mid]:  # If element is in the left half
            last_index = mid - 1
        else:  # Element found
            return mid
    
    return -1  # Element not found

# Main code
arr = []  # Initialize an empty array

# Input number of elements
n = int(input("Enter the number of elements: "))

# Input elements into the array
for i in range(n):
    b = int(input("Enter element: "))
    arr.append(b)

# Display the array
print("Array:", arr)

# Input the element to search
element = int(input("Enter element to be searched: "))

# Perform binary search
start_index = 0
last_index = len(arr) - 1
found = Binary_search(arr, start_index, last_index, element)

# Output the result
if found == -1:
    print("Element not present in the array.")
else:
    print(f"Element is present at index {found}.")

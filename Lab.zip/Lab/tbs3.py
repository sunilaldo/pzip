import seaborn as sns
import matplotlib.pyplot as plt  # Import this to use plt functions

import numpy as np

data = np.random.randn(1000)

sns.histplot(data, kde=True, color='purple')
plt.title("Seaborn Histogram with KDE")  # This uses plt to set the title
plt.show()

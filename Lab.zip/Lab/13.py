class Employee:
    def __init__(self, name, emp_id, salary, department):
        """Initialize the employee details."""
        self.name = name
        self.id = emp_id
        self.salary = salary
        self.department = department

    def calculate_salary(self, hours_worked):
        """Calculate salary based on overtime (if hours worked > 50)."""
        overtime = 0
        if hours_worked > 50:
            overtime = hours_worked - 50
            self.salary = self.salary + (overtime * (self.salary / 50))

    def assign_department(self, emp_department):
        """Assign a new department to the employee."""
        self.department = emp_department

    def print_employee_details(self):
        """Print employee details."""
        print("\nName: ", self.name)
        print("ID: ", self.id)
        print("Salary: ", self.salary)
        print("Department: ", self.department)
        print("----------------------")

# Creating Employee objects
employee1 = Employee("SHREE", "E3001", 610000, "ACCOUNTING")
employee2 = Employee("VISHNU", "E3002", 650000, "RESEARCH")
employee3 = Employee("ABINAYA", "E3003", 690000, "SALES")
employee4 = Employee("ARUNA", "E3004", 650000, "OPERATIONS")

# Print original employee details
print("Original Employee Details:")
employee1.print_employee_details()
employee2.print_employee_details()
employee3.print_employee_details()
employee4.print_employee_details()

# Assign new departments
employee1.assign_department("OPERATIONS")
employee4.assign_department("SALES")

# Calculate salaries with overtime
employee2.calculate_salary(62)  # Overtime for employee2
employee4.calculate_salary(70)  # Overtime for employee4

# Print updated employee details
print("Updated Employee Details:")
employee1.print_employee_details()
employee2.print_employee_details()
employee3.print_employee_details()
employee4.print_employee_details()

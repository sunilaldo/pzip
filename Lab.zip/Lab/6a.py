print("list is created in the name:list")
list=['V','P','M','V','B','S']
print("list created",list)
print("list indexing",list[0])
print("list negative indexing",list[-1])
print("list slicing",list[1:4])
list=['V','P','M','V','B','S']
print("Given list",list)
list[0]=2
print("List Changing",list)
list[1:4]=[12,34,23]
print("List Changing",list)
list = ['V','P','M','V','B','S']
print("Given list",list)
list[0]=22
print("List Changing",list)
list[1:4]=[12,34,23]
print("List Changing",list)
list = ['V','P','M','V','B','S']
print("Given list",list)
list.append(['Divide','Multi'])
print("List appending",list)
list=['V','P','M','V','B','S']
print("Given list",list)
list.remove('V')
print("List Removing",list)
list = ['V','P','M','V','B','S']
print("Given list",list)
list[2:5] = []
print("List Delete",list)

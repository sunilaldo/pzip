import pygal

bar_chart = pygal.Bar()
bar_chart.title = "Pygal Bar Chart"
bar_chart.add('A', 10)
bar_chart.add('B', 15)
bar_chart.add('C', 7)
bar_chart.render_in_browser()
